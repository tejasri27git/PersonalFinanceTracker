import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("../data/stock_data.csv")

# Show first 5 rows
print("Stock Data (first 5 rows):")
print(data.head())

# Convert Date column to datetime
data["Date"] = pd.to_datetime(data["Date"])

# Calculate moving averages
data["MA7"] = data["Close"].rolling(window=7).mean()
data["MA30"] = data["Close"].rolling(window=30).mean()

# Find highest and lowest closing price
highest = data["Close"].max()
lowest = data["Close"].min()
print(f"Highest Closing Price: {highest}")
print(f"Lowest Closing Price: {lowest}")

# Plot Closing Price + Moving Averages
plt.figure(figsize=(12, 6))
plt.plot(data["Date"], data["Close"], label="Closing Price", color="blue")
plt.plot(data["Date"], data["MA7"], label="7-Day MA", color="red")
plt.plot(data["Date"], data["MA30"], label="30-Day MA", color="green")

plt.xlabel("Date")
plt.ylabel("Price")
plt.title("Stock Market Analysis")
plt.legend()
plt.grid(True)
plt.show()
