from flask import Flask, render_template, request, redirect, url_for
import psycopg2
from collections import defaultdict

app = Flask(__name__)

def get_db_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="personal_finance",  # your DB name
        user="postgres",              # your pgAdmin username
        password="Tejasri@13"         # your pgAdmin password
    )
    return conn

@app.route('/')
def home():
    return redirect(url_for('dashboard'))

@app.route('/add-income', methods=['GET', 'POST'])
def add_income():
    if request.method == 'POST':
        source = request.form['source']
        amount = float(request.form['amount'])
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO income (source, amount) VALUES (%s, %s)', (source, amount))
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for('dashboard'))
    return render_template('add_income.html')

@app.route('/add-expense', methods=['GET', 'POST'])
def add_expense():
    if request.method == 'POST':
        name = request.form['name']
        amount = float(request.form['amount'])
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO expense (name, amount) VALUES (%s, %s)', (name, amount))
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for('dashboard'))
    return render_template('add_expense.html')

@app.route('/delete-income/<int:row_id>', methods=['POST'])
def delete_income(row_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM income WHERE id = %s', (row_id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/delete-expense/<int:row_id>', methods=['POST'])
def delete_expense(row_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM expense WHERE id = %s', (row_id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, source, amount FROM income ORDER BY id DESC;")
    incomes = cur.fetchall()
    cur.execute("SELECT id, name, amount FROM expense ORDER BY id DESC;")
    expenses = cur.fetchall()
    cur.execute("SELECT COALESCE(SUM(amount), 0) FROM income;")
    total_income = float(cur.fetchone()[0] or 0)
    cur.execute("SELECT COALESCE(SUM(amount), 0) FROM expense;")
    total_expense = float(cur.fetchone()[0] or 0)
    balance = total_income - total_expense
    cur.close()
    conn.close()
    income_agg = defaultdict(float)
    for _id, source, amount in incomes:
        income_agg[source] += float(amount)
    income_labels = list(income_agg.keys())
    income_amounts = list(income_agg.values())
    expense_agg = defaultdict(float)
    for _id, name, amount in expenses:
        expense_agg[name] += float(amount)
    expense_labels = list(expense_agg.keys())
    expense_amounts = list(expense_agg.values())
    return render_template(
        'dashboard.html',
        incomes=incomes,
        expenses=expenses,
        total_income=total_income,
        total_expense=total_expense,
        balance=balance,
        income_labels=income_labels,
        income_amounts=income_amounts,
        expense_labels=expense_labels,
        expense_amounts=expense_amounts
    )

if __name__ == '__main__':
    app.run(debug=True)





